package github.tommonpavou.mixin;

import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(ExperienceOrbEntity.class)
public abstract class ExperienceOrbMixin {

    @Inject(method = "spawn", at = @At("HEAD"), cancellable = true)
    private static void redirectExperienceToPlayer(ServerWorld world, Vec3d pos, int amount, CallbackInfo ci) {
        if (!world.isClient) {

                PlayerEntity nearestPlayer = world.getClosestPlayer(pos.x, pos.y, pos.z, 33.0, false);

                if (nearestPlayer != null) {
                    // Trova gli oggetti con Mending
                    List<ItemStack> mendingItems = new ArrayList<>();
                    for (ItemStack item : nearestPlayer.getItemsEquipped()) {
                        if (item.isDamageable() && isMendingPresent(item)) {
                            mendingItems.add(item);
                        }
                    }

                    int remainingXp = amount;

                    // Ripara oggetti con Mending
                    if (!mendingItems.isEmpty()) {
                        for (ItemStack item : mendingItems) {
                            if (remainingXp > 0) {
                                int damageBefore = item.getDamage();
                                int maxRepair = damageBefore * 2;
                                int repairAmount = Math.min(remainingXp * 2, maxRepair);

                                if (repairAmount > 0) {
                                    item.setDamage(damageBefore - (repairAmount / 2));
                                    remainingXp -= repairAmount / 2;
                                }
                            }
                        }
                    }

                    // Assegna il resto dell'XP al giocatore
                    if (remainingXp > 0) {
                        nearestPlayer.addExperience(remainingXp);
                    }

                    // Cancella il comportamento originale
                    ci.cancel();
                }
            }
        }

    private static boolean isMendingPresent(ItemStack item) {
        NbtList enchantments = item.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");

            if ("minecraft:mending".equals(enchantmentId)) {
                return true;
            }
        }
        return false;
    }
}
