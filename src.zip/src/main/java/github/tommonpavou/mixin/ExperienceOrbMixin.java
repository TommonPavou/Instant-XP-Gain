package github.tommonpavou.mixin;

import github.tommonpavou.interfaces.EnderDragonExperienceOrb;
import github.tommonpavou.utils.ExperienceTypeManager;
import github.tommonpavou.utils.MendingManager;

import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceOrbEntity.class)
public abstract class ExperienceOrbMixin implements EnderDragonExperienceOrb {

    private boolean fromEnderDragon = false;

    @Override
    public boolean isFromEnderDragon() {
        return this.fromEnderDragon;
    }

    @Override
    public void setFromEnderDragon(boolean value) {
        this.fromEnderDragon = value;
    }

    @Inject(method = "spawn", at = @At("HEAD"), cancellable = true)
    private static void redirectExperienceToPlayer(ServerWorld world, Vec3d pos, int amount, CallbackInfo ci) {
        if (!world.isClient) {
            ExperienceOrbEntity xpOrb = new ExperienceOrbEntity(world, pos.x, pos.y, pos.z, amount);

            if (ExperienceTypeManager.isExperienceOrbFromEnderDragon(xpOrb)) {
                return; // Non modificare gli orb provenienti dal drago
            }

            PlayerEntity nearestPlayer = world.getClosestPlayer(pos.x, pos.y, pos.z, 33.0,
                    player -> !player.isSpectator() && player.isAlive());

            if (nearestPlayer != null) {
                int remainingXp = MendingManager.applyMending(nearestPlayer, amount);

                if (remainingXp > 0) {
                    nearestPlayer.addExperience(remainingXp);
                }

                // Cancella la generazione dell'orb, esperienza già assegnata
                ci.cancel();
            }
        }
    }
}
