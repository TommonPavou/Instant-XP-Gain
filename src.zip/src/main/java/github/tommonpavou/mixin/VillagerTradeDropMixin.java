package github.tommonpavou.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.village.TradeOffer;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Mixin(MerchantEntity.class)
public abstract class VillagerTradeDropMixin {

    @Shadow public abstract void setCustomer(@Nullable PlayerEntity customer);

    @Shadow @Nullable private PlayerEntity customer;

    @Inject(method = "trade", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(TradeOffer offer, CallbackInfo ci) {
        VillagerEntity trader = (VillagerEntity) (Object) this;

        if (trader.getWorld() != null && customer != null) {
            Random random = new Random();
            int xpAmount = random.nextInt(4) + 3;

            // Trova oggetti con Mending
            List<ItemStack> mendingItems = new ArrayList<>();
            for (ItemStack item : customer.getItemsEquipped()) {
                if (item.isDamageable() && isMendingPresent(item)) {
                    mendingItems.add(item);
                }
            }

            if (!mendingItems.isEmpty()) {
                int remainingXp = xpAmount;

                for (ItemStack item : mendingItems) {
                    if (remainingXp > 0) {
                        int damageBefore = item.getDamage();
                        int maxRepair = damageBefore * 2;
                        int repairAmount = Math.min(remainingXp * 2, maxRepair);

                        if (repairAmount > 0) {
                            item.setDamage(damageBefore - (repairAmount / 2));
                            remainingXp -= repairAmount / 2;
                        }
                    }
                }

                if (remainingXp > 0) {
                    customer.addExperience(remainingXp);
                }
                ci.cancel();
            } else {
                customer.addExperience(xpAmount);
                ci.cancel();
            }
        }
    }

    private boolean isMendingPresent(ItemStack item) {
        NbtList enchantments = item.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            if ("minecraft:mending".equals(enchantmentData.getString("id"))) {
                return true;
            }
        }
        return false;
    }
}
