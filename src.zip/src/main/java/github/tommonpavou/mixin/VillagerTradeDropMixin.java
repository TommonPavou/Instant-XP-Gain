package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.village.TradeOffer;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


import java.util.Random;

@Mixin(MerchantEntity.class)
public abstract class VillagerTradeDropMixin {

    @Shadow @Nullable private PlayerEntity customer;

    @Inject(method = "trade", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(TradeOffer offer, CallbackInfo ci) {
        VillagerEntity trader = (VillagerEntity) (Object) this;

        if (trader.getWorld() != null && customer != null) {
            Random random = new Random();
            int xp = random.nextInt(4) + 3;

                // Usa il MendingManager per applicare il mending
                int remainingXp = MendingManager.applyMending(customer, xp);

                // Assegna il resto dell'XP al giocatore
                if (remainingXp > 0) {
                    customer.addExperience(remainingXp);
                }

        }
        // Cancella il comportamento originale
        ci.cancel();
    }
}