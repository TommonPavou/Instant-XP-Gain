package github.tommonpavou.mixin;

import github.tommonpavou.utils.DelayedExperience;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class EntityDropMixin {

	@Inject(method = "dropExperience", at = @At("HEAD"), cancellable = true)
	public void redirectExperienceToPlayer(ServerLevel serverLevel, Entity killer, CallbackInfo ci) {
        if (serverLevel.isClientSide()) return;
        
		LivingEntity entity = (LivingEntity) (Object) this;

        // Identifica il player che ha causato l'ultimo danno, se presente
        Player player;

        // Controlla se l'attaccante è un player o un proiettile lanciato da un player
        if (killer instanceof Player playerChecked) {
            player = playerChecked;
        } else if (killer instanceof Projectile projectile
                && projectile.getOwner() instanceof Player playerChecked) {
            player = playerChecked;
        } else {
            player = null;
        }

        if (player == null) return;

        // Verifica quanta XP l'entità rilascia
        int experience = entity.getExperienceReward(serverLevel, killer);
        if (experience <= 0) {
            ci.cancel();
            return;
        }

        BlockPos entityPos = entity.blockPosition();

        // Controlla se c'è uno Sculk Catalyst nel raggio di 8 blocchi usando la distanza al quadrato
        boolean hasSculkCatalystNearby = false;
        int radiusSquared = 64; // 8 * 8

        for (BlockPos pos : BlockPos.withinManhattan(entityPos, 8, 8, 8)) {
            if (serverLevel.getBlockState(pos).is(Blocks.SCULK_CATALYST)) {
                // Calcolo manuale della distanza al quadrato
                int dx = entityPos.getX() - pos.getX();
                int dy = entityPos.getY() - pos.getY();
                int dz = entityPos.getZ() - pos.getZ();
                int distanceSquared = dx * dx + dy * dy + dz * dz;

                if (distanceSquared <= radiusSquared) {
                    hasSculkCatalystNearby = true;
                    break;
                }
            }
        }

        if (hasSculkCatalystNearby) {
            ci.cancel();
            return;
        }

        // L'arma melee perde durabilita' dopo dropExperience. L'XP arriva al tick successivo.
        DelayedExperience.schedule(player, experience);

        ci.cancel();
    }
}
