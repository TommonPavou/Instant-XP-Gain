package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityDeathDropMixin {

    @Shadow
    public abstract int getXpToDrop();

    @Shadow
    protected abstract void dropInventory();

    @Inject(method = "onDeath", at = @At("HEAD"), cancellable = true)
    private void onDeath(DamageSource source, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;

        // Verifica che il mondo sia un'istanza di ServerWorld
        if (!(player.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }

        // Verifica se il gamerule KEEP_INVENTORY è attivo
        if (serverWorld.getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
            ci.cancel(); // Annulla la gestione standard della morte
            return;
        }

        int xp = getXpToDrop();
        if (xp <= 0) {
            return; // Se non c'è XP da droppare, esci
        }

        PlayerEntity targetPlayer = null;

        // Controlla se l'attaccante è un giocatore
        if (source.getAttacker() instanceof PlayerEntity killer) {
            targetPlayer = killer;
        }

        if (targetPlayer != null) {
            // Applica la logica del mending
            int remainingXp = MendingManager.applyMending(targetPlayer, xp);

            // Aggiungi l'esperienza residua al giocatore
            if (remainingXp > 0) {
                targetPlayer.addExperience(remainingXp);
            }
        }

        // Droppa l'inventario del giocatore
        this.dropInventory();

        // Annulla il comportamento originale
        ci.cancel();
    }
}
