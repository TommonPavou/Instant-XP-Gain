package github.tommonpavou.mixin;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.world.GameRules;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityDeathDropMixin {

    @Shadow
    public abstract int getXpToDrop();

    @Unique
    public abstract void dropInventory();

    @Inject(method = "onDeath", at = @At("HEAD"), cancellable = true)
    private void onDeath(DamageSource source, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        ServerWorld world = (ServerWorld) player.getWorld();

        // Verifica se KEEP_INVENTORY è attivo
        if (world.getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
            ci.cancel();
            return;
        }

        int xpToDrop = getXpToDrop();
        PlayerEntity targetPlayer = null;

        // Verifica se un player ha ucciso il giocatore
        if (source.getAttacker() instanceof PlayerEntity killer) {
                targetPlayer = killer;
        }

        if (targetPlayer != null) {
            // Trova gli oggetti con Mending del giocatore
            List<ItemStack> mendingItems = new ArrayList<>();
            for (ItemStack item : targetPlayer.getItemsEquipped()) {
                if (item.isDamageable() && isMendingPresent(item)) {
                    mendingItems.add(item);
                }
            }

            int remainingXp = xpToDrop;

            // Ripara oggetti con Mending
            if (!mendingItems.isEmpty()) {
                for (ItemStack item : mendingItems) {
                    if (remainingXp > 0) {
                        int damageBefore = item.getDamage();
                        int maxRepair = damageBefore * 2;
                        int repairAmount = Math.min(remainingXp * 2, maxRepair);

                        if (repairAmount > 0) {
                            item.setDamage(damageBefore - (repairAmount / 2));
                            remainingXp -= repairAmount / 2;
                        }
                    }
                }
            }

            // Assegna il resto dell'XP al giocatore
            if (remainingXp > 0) {
                targetPlayer.addExperience(remainingXp);
            }
        }

        // Droppa l'inventario e cancella il comportamento normale
        this.dropInventory();
        ci.cancel();
    }

    private static boolean isMendingPresent(ItemStack item) {
        NbtList enchantments = item.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");

            if ("minecraft:mending".equals(enchantmentId)) {
                return true;
            }
        }
        return false;
    }
}
