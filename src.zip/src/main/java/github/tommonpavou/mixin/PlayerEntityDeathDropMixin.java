package github.tommonpavou.mixin;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityDeathDropMixin {

    @Shadow
    public abstract int getXpToDrop();

    @Unique
    public abstract void dropInventory(Difficulty difficulty);

    @Inject(method = "onDeath", at = @At("HEAD"), cancellable = true)
    private void onDeath(DamageSource source, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;

        // Verifica se il giocatore è in modalità creativa o se KEEP_INVENTORY è attivo
        if (player.getWorld().getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
            ci.cancel(); // Evita che l'inventario venga rilasciato se KEEP_INVENTORY è attivo.
            return;
        }

        // Verifica se il giocatore è stato ucciso da un altro giocatore
        if (source.getAttacker() instanceof PlayerEntity killer) {
            if (!killer.isCreative()) {
                // Se il killer non è in modalità creativa, assegna l'XP al killer
                killer.addExperience(getXpToDrop());
                ci.cancel(); // Impedisce che l'XP venga rilasciato come entità.
            }
        } else if (source.getAttacker() instanceof MobEntity) {
            // Se un mob ha ucciso il giocatore, rilascia comunque XP al giocatore
            this.dropInventory(player.getWorld().getDifficulty());
            ci.cancel(); // Impedisce che l'XP venga rilasciato come entità.
        } else {
            // Se non è un mob che ha ucciso il giocatore, rilascia XP solo se la difficoltà non è PEACEFUL
            if (player.getWorld().getDifficulty() != Difficulty.PEACEFUL) {
                this.dropInventory(player.getWorld().getDifficulty());
            }
            ci.cancel(); // Impedisce che l'XP venga rilasciato come entità.
        }
    }
}