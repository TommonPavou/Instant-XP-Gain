package github.tommonpavou.mixin;

import github.tommonpavou.interfaces.EnderDragonExperienceOrb;

import github.tommonpavou.utils.ExperienceTypeManager;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.phase.PhaseManager;
import net.minecraft.entity.boss.dragon.phase.PhaseType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Mixin(PhaseManager.class)
public class EnderDragonDropMixin {

    @Inject(method = "setPhase", at = @At("HEAD"))
    private void onDragonPhaseSet(PhaseType<?> phaseType, CallbackInfo ci) {
        PhaseManager phaseManager = (PhaseManager) (Object) this;
        EnderDragonEntity dragon = ((PhaseManagerAccessor) phaseManager).getDragon();

        if (phaseType == PhaseType.DYING && !dragon.getWorld().isClient()) {
            ServerWorld world = (ServerWorld) dragon.getWorld();
            AtomicBoolean xpDropped = new AtomicBoolean(false);
            AtomicReference<BlockPos> lastKnownPosition = new AtomicReference<>(dragon.getBlockPos());

            // Thread per tracciare il movimento del drago fino al rilascio dell'XP
            new Thread(() -> {
                try {
                    for (int i = 0; i < 120; i++) { // 12 secondi di monitoraggio
                        Thread.sleep(100);
                        if (!xpDropped.get()) {
                            lastKnownPosition.set(dragon.getBlockPos());
                        } else {
                            return;
                        }
                    }

                    // Se il drago è sopra il pilastro centrale
                    BlockPos finalPosition = lastKnownPosition.get();
                    if (finalPosition.getX() == 0 && finalPosition.getZ() == 0) {
                        Thread.sleep(4500); // Aspetta ulteriori 4.5 secondi
                    }

                    // Rilascia l'XP
                    if (!xpDropped.get()) {
                        dropXP(world, lastKnownPosition.get(), dragon);
                        xpDropped.set(true);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    private void dropXP(ServerWorld world, BlockPos position, EnderDragonEntity dragon) {
        int xpAmount = dragon.getFight().hasPreviouslyKilled() ? 500 : 12000;
        Vec3d dropPosition = new Vec3d(position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5);

        world.getServer().execute(() -> {
            if (xpAmount == 12000) {
                // Genera un'orb da 2400 XP
                ExperienceOrbEntity xpOrb2400 = new ExperienceOrbEntity(world, dropPosition.x, dropPosition.y, dropPosition.z, 2400);
                ((EnderDragonExperienceOrb) xpOrb2400).setFromEnderDragon(true);
                ExperienceTypeManager.setExperienceOrbFromEnderDragon(xpOrb2400, true);
                world.spawnEntity(xpOrb2400);

                // Genera 10 orb da 960 XP
                for (int i = 0; i < 10; i++) {
                    ExperienceOrbEntity xpOrb960 = new ExperienceOrbEntity(world, dropPosition.x, dropPosition.y, dropPosition.z, 960);
                    ((EnderDragonExperienceOrb) xpOrb960).setFromEnderDragon(true);
                    ExperienceTypeManager.setExperienceOrbFromEnderDragon(xpOrb960, true);
                    world.spawnEntity(xpOrb960);
                }
            } else {
                // Genera 10 orb da 50 XP
                for (int i = 0; i < 10; i++) {
                    ExperienceOrbEntity xpOrb50 = new ExperienceOrbEntity(world, dropPosition.x, dropPosition.y, dropPosition.z, 50);
                    ((EnderDragonExperienceOrb) xpOrb50).setFromEnderDragon(true);
                    ExperienceTypeManager.setExperienceOrbFromEnderDragon(xpOrb50, true);
                    world.spawnEntity(xpOrb50);
                }
            }
        });
    }
}