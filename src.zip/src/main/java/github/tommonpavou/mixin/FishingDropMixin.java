package github.tommonpavou.mixin;

public class FishingDropMixin {
}
