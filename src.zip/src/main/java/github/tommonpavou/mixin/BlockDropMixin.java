package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import github.tommonpavou.utils.SilkTouchManager;

import net.minecraft.block.BlockState;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.intprovider.IntProvider;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(ExperienceDroppingBlock.class)
public abstract class BlockDropMixin {

    @Shadow
    @Final
    private IntProvider experienceDropped;

    @Inject(method = "onStacksDropped", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(
            BlockState state, ServerWorld world, BlockPos pos, ItemStack tool, boolean dropExperience, CallbackInfo ci
    ) {
        // Usa il SilkManager per verificare la presenza di silk touch
        if (!world.isClient && dropExperience && !SilkTouchManager.hasSilkTouch(tool)) {
            int xp = experienceDropped.get(world.random);

            if (xp > 0) {
                PlayerEntity nearestPlayer = world.getClosestPlayer(
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        12.0, false);

                if (nearestPlayer != null) {
                    // Usa il MendingManager per applicare il mending
                    int remainingXp = MendingManager.applyMending(nearestPlayer, xp);

                    // Assegna il resto dell'XP al giocatore
                    if (remainingXp > 0) {
                        nearestPlayer.addExperience(remainingXp);
                    }

                }
            }
            // Cancella il comportamento originale
            ci.cancel();
        }
    }
}