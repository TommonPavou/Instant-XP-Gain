package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import github.tommonpavou.utils.SilkTouchManager;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DropExperienceBlock.class)
public abstract class BlockDropMixin {

    @Shadow
    @Final
    private IntProvider xpRange;

    @Inject(method = "spawnAfterBreak", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(BlockState state, ServerLevel serverLevel, BlockPos pos, ItemStack tool, boolean dropExperience, CallbackInfo ci) {
        if (serverLevel.isClientSide()) return;

        // Usa il SilkManager per verificare la presenza di silk touch
        if (dropExperience && !SilkTouchManager.isSilkTouchPresent(tool)) {
            int experience = xpRange.sample(serverLevel.getRandom());

            if (experience > 0) {
                Player nearestPlayer = serverLevel.getNearestPlayer(
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        12.0, false);

                // Se c'è un giocatore vicino, applica il mending e assegna l'XP rimanente
                if (nearestPlayer != null) {
                    int remainingXp = MendingManager.applyMending(nearestPlayer, experience);
                    if (remainingXp > 0) nearestPlayer.giveExperiencePoints(remainingXp);
                }
            }

            // Cancella il comportamento originale
            ci.cancel();
        }
    }
}