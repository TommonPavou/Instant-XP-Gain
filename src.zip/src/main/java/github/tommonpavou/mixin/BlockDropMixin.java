package github.tommonpavou.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(ExperienceDroppingBlock.class)
public abstract class BlockDropMixin {

    @Shadow
    @Final
    private IntProvider experienceDropped;

    @Inject(method = "onStacksDropped", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(
            BlockState state, ServerWorld world, BlockPos pos, ItemStack tool, boolean dropExperience, CallbackInfo ci
    ) {
        if (!world.isClient && dropExperience) {
            int xp = experienceDropped.get(world.random);

            if (xp > 0) {
                PlayerEntity nearestPlayer = world.getClosestPlayer(
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        12.0, false
                );

                if (nearestPlayer != null) {
                    // Trova gli oggetti con Mending
                    List<ItemStack> mendingItems = new ArrayList<>();
                    for (ItemStack item : nearestPlayer.getItemsEquipped()) {
                        if (item.isDamageable() && isMendingPresent(item)) {
                            mendingItems.add(item);
                        }
                    }

                    // Se ci sono oggetti con Mending
                    if (!mendingItems.isEmpty()) {
                        int remainingXp = xp; // Manteniamo il conteggio dell'XP totale

                        for (ItemStack item : mendingItems) {
                            if (remainingXp > 0) {
                                int damageBefore = item.getDamage();
                                int maxRepair = damageBefore * 2; // XP necessario per riparare completamente
                                int repairAmount = Math.min(remainingXp * 2, maxRepair); // Limita la riparazione al danno massimo

                                if (repairAmount > 0) {
                                    item.setDamage(damageBefore - (repairAmount / 2)); // Riduci il danno
                                    remainingXp -= repairAmount / 2; // Riduci l'XP restante
                                }
                            }
                        }

                        // Se rimane XP non utilizzato, assegnalo al giocatore
                        if (remainingXp > 0) {
                            nearestPlayer.addExperience(remainingXp);
                        }

                        // Cancella il normale comportamento
                        ci.cancel();
                    } else {
                        // Nessun oggetto con Mending, XP direttamente al giocatore
                        nearestPlayer.addExperience(xp);
                    }
                } else {

                    // Cancella comunque il normale comportamento
                    ci.cancel();
                }
            }
        }
    }

    private boolean isMendingPresent(ItemStack item) {
        // Estraiamo la lista di incantamenti
        NbtList enchantments = item.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");

            if ("minecraft:mending".equals(enchantmentId)) { // ID corretto di Mending
                return true; // Se l'incantamento è Mending, ritorniamo true
            }
        }
        return false;
    }

}