package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(LivingEntity.class)
public abstract class EntityDeathDropMixin {

	@Inject(method = "dropXp", at = @At("HEAD"), cancellable = true)
	public void redirectExperienceToPlayer(CallbackInfo ci) {
		LivingEntity entity = (LivingEntity) (Object) this;

		if (entity.getWorld() instanceof ServerWorld serverWorld) {
			PlayerEntity killer = entity.getAttacker() instanceof PlayerEntity ? (PlayerEntity) entity.getAttacker() : null;

			if (killer != null) {
				int xp = entity.getXpToDrop();
				BlockPos entityPos = entity.getBlockPos();

				// Controlla se c'è uno Sculk Catalyst nel raggio di 7 blocchi usando la distanza al quadrato
				boolean hasSculkCatalystNearby = false;
				int radiusSquared = 49; // 7 * 7

				for (BlockPos pos : BlockPos.iterateOutwards(entityPos, 7, 7, 7)) {
					if (serverWorld.getBlockState(pos).isOf(Blocks.SCULK_CATALYST)) {
						// Calcolo manuale della distanza al quadrato
						int dx = entityPos.getX() - pos.getX();
						int dy = entityPos.getY() - pos.getY();
						int dz = entityPos.getZ() - pos.getZ();
						int distanceSquared = dx * dx + dy * dy + dz * dz;

						if (distanceSquared <= radiusSquared) {
							hasSculkCatalystNearby = true;
							break;
						}
					}
				}

				if (hasSculkCatalystNearby) {
					// Cancella il rilascio di XP se c'è uno Sculk Catalyst vicino
					ci.cancel();
					return;
				}

				if (killer != null) {
					// Usa il MendingManager per applicare il mending
					int remainingXp = MendingManager.applyMending(killer, xp);

					// Assegna il resto dell'XP al giocatore
					if (remainingXp > 0) {
						killer.addExperience(remainingXp);
					}

				}
			}
			// Cancella il comportamento originale
			ci.cancel();
		}
	}
}