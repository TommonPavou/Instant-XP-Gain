package github.tommonpavou.mixin;

import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(LivingEntity.class)
public abstract class EntityDeathDropMixin {

	@Inject(method = "dropXp", at = @At("HEAD"), cancellable = true)
	public void redirectExperienceToPlayer(CallbackInfo ci) {
		LivingEntity entity = (LivingEntity) (Object) this;

		if (entity.getWorld() instanceof ServerWorld serverWorld) {
			PlayerEntity killer = entity.getAttacker() instanceof PlayerEntity ? (PlayerEntity) entity.getAttacker() : null;

			if (killer != null) {
				int xpAmount = entity.getXpToDrop();
				BlockPos entityPos = entity.getBlockPos();

				// Controlla se c'è uno Sculk Catalyst nel raggio di 7 blocchi usando la distanza al quadrato
				boolean hasSculkCatalystNearby = false;
				int radiusSquared = 49; // 7 * 7

				for (BlockPos pos : BlockPos.iterateOutwards(entityPos, 7, 7, 7)) {
					if (serverWorld.getBlockState(pos).isOf(Blocks.SCULK_CATALYST)) {
						// Calcolo manuale della distanza al quadrato
						int dx = entityPos.getX() - pos.getX();
						int dy = entityPos.getY() - pos.getY();
						int dz = entityPos.getZ() - pos.getZ();
						int distanceSquared = dx * dx + dy * dy + dz * dz;

						if (distanceSquared <= radiusSquared) {
							hasSculkCatalystNearby = true;
							break;
						}
					}
				}

				if (hasSculkCatalystNearby) {
					// Cancella il rilascio di XP se c'è uno Sculk Catalyst vicino
					ci.cancel();
					return;
				}

				// Trova oggetti con Mending
				List<ItemStack> mendingItems = new ArrayList<>();
				for (ItemStack item : killer.getItemsEquipped()) {
					if (item.isDamageable() && isMendingPresent(item)) {
						mendingItems.add(item);
					}
				}

				if (!mendingItems.isEmpty()) {
					int remainingXp = xpAmount;

					for (ItemStack item : mendingItems) {
						if (remainingXp > 0) {
							int damageBefore = item.getDamage();
							int maxRepair = damageBefore * 2;
							int repairAmount = Math.min(remainingXp * 2, maxRepair);

							if (repairAmount > 0) {
								item.setDamage(damageBefore - (repairAmount / 2));
								remainingXp -= repairAmount / 2;
							}
						}
					}

					if (remainingXp > 0) {
						killer.addExperience(remainingXp);
					}
					ci.cancel();
				} else {
					killer.addExperience(xpAmount);
					ci.cancel();
				}
			}
		}
	}

	private boolean isMendingPresent(ItemStack item) {
		NbtList enchantments = item.getEnchantments();
		for (int i = 0; i < enchantments.size(); i++) {
			NbtCompound enchantmentData = enchantments.getCompound(i);
			if ("minecraft:mending".equals(enchantmentData.getString("id"))) {
				return true;
			}
		}
		return false;
	}
}