package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerLevel.class)
public class BreedingDropMixin {

    /*
     Se ti fossi dimenticato a cosa serve questo mixin te lo spiego io.
     Serve a intercettare la generazione di XP quando viene chiamato il metodo spawnEntity,
     questo perché é l'unico metodo che non intercetta con altri mixin come EtityDropMixin
     e vale anche per le orb generate dalle bottiglie di esperienza. Prego :D
     */

    @Inject(method = "addFreshEntity", at = @At("HEAD"), cancellable = true)
    private void onSpawnEntity(Entity entity, CallbackInfoReturnable<Boolean> cir) {

        if (!(entity instanceof ExperienceOrb xpOrb)) return;

        ServerLevel serverLevel = (ServerLevel)(Object)this;

        // Verifica se il drago è morto da meno di 15 secondi (l'esperienza viene rilasciata dopo 10)
        if (serverLevel.getDragonFight() != null) {
            EnderDragon enderDragon = (EnderDragon) serverLevel.getEntity(serverLevel.getDragonFight().dragonUUID());
            if (enderDragon != null) {
                if (enderDragon.dragonDeathTime <= 300) return;
            }
        }

        // Controlla se l'orb nasce entro 1.5 blocchi di un mercante (villager o wandering trader)
        boolean isMerchantNearby = !serverLevel.getEntitiesOfClass(AbstractVillager.class, new AABB(
                        xpOrb.getX() - 3, xpOrb.getY() - 3, xpOrb.getZ() - 3,
                        xpOrb.getX() + 3, xpOrb.getY() + 3, xpOrb.getZ() + 3),
                merchant -> true
        ).isEmpty();

        // Se l'orb è stata generata da un villager trade, lasciamo che venga spawnata normalmente.
        // Dopo un tick di gioco verrà intercettata e convertita in esperienza diretta al player.
        // Questo evita di interrompere il normale flow del trading e dei rispettivi advancement.
        if (isMerchantNearby) {
            serverLevel.getServer().execute(() -> {

                // Se per qualche motivo l'orb non esiste più non facciamo nulla
                if (!xpOrb.isAlive()) return;

                // Trova il player più vicino entro 33 blocchi
                Player nearestPlayer = serverLevel.getNearestPlayer(
                        xpOrb.getX(),
                        xpOrb.getY(),
                        xpOrb.getZ(),
                        33.0,
                        player -> !player.isSpectator() && player.isAlive()
                );

                if (nearestPlayer != null) {
                    int remainingXp = MendingManager.applyMending(nearestPlayer, xpOrb.getValue());
                    if (remainingXp > 0) nearestPlayer.giveExperiencePoints(remainingXp);
                }

                // Rimuove l'orb dal mondo per evitare entity load
                xpOrb.discard();
            });

            return;
        }

        // Trova il giocatore più vicino all'orb entro 33 blocchi
        Player nearestPlayer = serverLevel.getNearestPlayer(
                xpOrb.getX(),
                xpOrb.getY(),
                xpOrb.getZ(),
                33.0,
                player -> !player.isSpectator() && player.isAlive()
        );

        if (nearestPlayer == null) {
            cir.cancel();
            return;
        }

        int remainingXp = MendingManager.applyMending(nearestPlayer, xpOrb.getValue());
        if (remainingXp > 0) nearestPlayer.giveExperiencePoints(remainingXp);

        // Cancella il comportamento originale
        cir.cancel();
    }
}