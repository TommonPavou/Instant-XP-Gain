package github.tommonpavou.mixin;

import github.tommonpavou.utils.ExperienceTypeManager;
import github.tommonpavou.utils.MendingManager;

import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerWorld.class)
public class BreedingDropMixin {

    @Inject(method = "spawnEntity", at = @At("HEAD"), cancellable = true)
    private void onSpawnEntity(net.minecraft.entity.Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof ExperienceOrbEntity xpOrb) {
            // Non annullare la generazione per gli orb provenienti dal drago
            if (ExperienceTypeManager.isExperienceOrbFromEnderDragon(xpOrb)) {
                return;
            }

            ServerWorld serverWorld = (ServerWorld) (Object) this;

            // Trova il giocatore più vicino entro 33 blocchi
            PlayerEntity nearestPlayer = serverWorld.getClosestPlayer(xpOrb.getX(), xpOrb.getY(), xpOrb.getZ(), 33,
                    player -> !player.isSpectator() && player.isAlive());

            if (nearestPlayer != null) {
                int remainingXp = MendingManager.applyMending(nearestPlayer, xpOrb.getExperienceAmount());
                if (remainingXp > 0) {
                    nearestPlayer.addExperience(remainingXp);
                }
                cir.cancel(); // Non genera l'orb
            } else {
                cir.cancel(); // Annulla l'orb se nessun giocatore è vicino
            }
        }
    }
}
