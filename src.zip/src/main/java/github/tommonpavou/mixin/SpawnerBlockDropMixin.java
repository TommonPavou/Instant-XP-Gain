package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import github.tommonpavou.utils.SilkTouchManager;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.SpawnerBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SpawnerBlock.class)
public abstract class SpawnerBlockDropMixin {

    @Inject(method = "spawnAfterBreak", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(BlockState state, ServerLevel serverLevel, BlockPos position, ItemStack tool, boolean dropExperience, CallbackInfo ci) {
        if (serverLevel.isClientSide()) return;

        // Usa il SilkManager per verificare la presenza di silk touch
        if (dropExperience && !SilkTouchManager.isSilkTouchPresent(tool)) {
            // Calcola la quantità di esperienza rilasciata dagli spawner
            int experience = 15 + serverLevel.getRandom().nextInt(15) + serverLevel.getRandom().nextInt(15);

            // Trova il giocatore più vicino
            Player nearestPlayer = serverLevel.getNearestPlayer(
                    position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5,
                    10.0, false
            );

            // Se c'è un giocatore vicino, applica il mending e assegna l'XP rimanente
            if (nearestPlayer != null) {
                int remainingXp = MendingManager.applyMending(nearestPlayer, experience);
                if (remainingXp > 0) nearestPlayer.giveExperiencePoints(remainingXp);
            }

            // Cancella il comportamento originale
            ci.cancel();
        }
    }
}