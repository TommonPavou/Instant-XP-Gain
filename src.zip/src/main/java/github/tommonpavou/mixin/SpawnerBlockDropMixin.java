package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.SpawnerBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(SpawnerBlock.class)
public abstract class SpawnerBlockDropMixin {

    @Inject(method = "onStacksDropped", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(
            BlockState state, ServerWorld world, BlockPos pos, ItemStack tool, boolean dropExperience, CallbackInfo ci
    ) {
        if (!world.isClient && dropExperience) {
            // Calcola la quantità di esperienza rilasciata dagli spawner
            int xp = 15 + world.random.nextInt(15) + world.random.nextInt(15);

            // Trova il giocatore più vicino
            PlayerEntity nearestPlayer = world.getClosestPlayer(
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    10.0, false
            );

            if (nearestPlayer != null) {
                // Usa il MendingManager per applicare il mending
                int remainingXp = MendingManager.applyMending(nearestPlayer, xp);

                // Assegna il resto dell'XP al giocatore
                if (remainingXp > 0) {
                    nearestPlayer.addExperience(remainingXp);
                }

            }
            // Cancella il comportamento originale
            ci.cancel();
        }
    }
}