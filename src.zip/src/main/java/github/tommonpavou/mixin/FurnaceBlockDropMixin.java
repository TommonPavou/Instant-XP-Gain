package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class FurnaceBlockDropMixin {

    @Inject(method = "dropExperience", at = @At("HEAD"), cancellable = true)
    private static void redirectExperienceToPlayer(
            ServerWorld world, Vec3d pos, int multiplier, float experience, CallbackInfo ci
    ) {
        if (!world.isClient) {
            float xp1 = experience * multiplier; // Quantità di XP da distribuire
            int xp = (int) Math.ceil(xp1);

            PlayerEntity nearestPlayer = world.getClosestPlayer(
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    10.0, false // Raggio di ricerca: 10 blocchi
            );

            if (nearestPlayer != null) {
                // Usa il MendingManager per applicare il mending
                int remainingXp = MendingManager.applyMending(nearestPlayer, xp);

                // Assegna il resto dell'XP al giocatore
                if (remainingXp > 0) {
                    nearestPlayer.addExperience(remainingXp);
                }

            }
            // Cancella il comportamento originale
            ci.cancel();
        }
    }
}