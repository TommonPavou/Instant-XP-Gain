package github.tommonpavou.mixin;

import github.tommonpavou.utils.MendingManager;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class FurnaceBlockDropMixin {

    @Inject(method = "createExperience", at = @At("HEAD"), cancellable = true)
    private static void redirectExperienceToPlayer(ServerLevel serverLevel, Vec3 position, int multiplier, float amount, CallbackInfo ci) {
        if (serverLevel.isClientSide()) return;

        float experience = amount * multiplier; // Quantità di XP da distribuire
        int totalExperience = (int) Math.ceil(experience);

        Player nearestPlayer = serverLevel.getNearestPlayer(
                position.x() + 0.5, position.y() + 0.5, position.z() + 0.5,
                10.0, false // Raggio di ricerca: 10 blocchi
        );

        // Se c'è un giocatore vicino, applica il mending e assegna l'XP rimanente
        if (nearestPlayer != null) {
            int remainingXp = MendingManager.applyMending(nearestPlayer, totalExperience);
            if (remainingXp > 0) nearestPlayer.giveExperiencePoints(remainingXp);
        }

        // Cancella il comportamento originale
        ci.cancel();
    }
}