package github.tommonpavou.mixin;

import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.phase.PhaseManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

// Serve per accedere alle fasi della battaglia del "dragon"
@Mixin(PhaseManager.class)
public interface PhaseManagerAccessor {
    @Accessor("dragon")
    EnderDragonEntity getDragon();
}
