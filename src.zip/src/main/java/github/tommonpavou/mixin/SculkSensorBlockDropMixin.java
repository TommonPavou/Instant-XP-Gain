package github.tommonpavou.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.block.SculkSensorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(SculkSensorBlock.class)
public abstract class SculkSensorBlockDropMixin {

    @Inject(method = "onStacksDropped", at = @At("HEAD"), cancellable = true)
    private void redirectExperienceToPlayer(
            BlockState state, ServerWorld world, BlockPos pos, ItemStack tool, boolean dropExperience, CallbackInfo ci
    ) {
        if (!world.isClient && dropExperience) {
            int xp = 1; // Quantità di XP da distribuire (puoi modificarlo in base al comportamento desiderato)

            PlayerEntity nearestPlayer = world.getClosestPlayer(
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    10.0, false // Raggio di ricerca: 10 blocchi
            );

            if (nearestPlayer != null) {
                // Trova gli oggetti con Mending equipaggiati dal giocatore
                List<ItemStack> mendingItems = new ArrayList<>();
                for (ItemStack item : nearestPlayer.getItemsEquipped()) {
                    if (item.isDamageable() && isMendingPresent(item)) {
                        mendingItems.add(item);
                    }
                }

                // Applica la riparazione con Mending
                int remainingXp = xp;
                for (ItemStack item : mendingItems) {
                    if (remainingXp > 0) {
                        int damageBefore = item.getDamage();
                        int maxRepair = damageBefore * 2; // XP necessario per riparare completamente
                        int repairAmount = Math.min(remainingXp * 2, maxRepair); // Ripara fino al massimo danno

                        if (repairAmount > 0) {
                            item.setDamage(damageBefore - (repairAmount / 2)); // Riduci il danno
                            remainingXp -= repairAmount / 2; // Riduci l'XP rimanente
                        }
                    }
                }

                // Se rimane XP, assegnalo direttamente al giocatore
                if (remainingXp > 0) {
                    nearestPlayer.addExperience(remainingXp);
                }

                // Cancella il normale comportamento del blocco
                ci.cancel();
            }
        }
    }


    private boolean isMendingPresent(ItemStack item) {
        NbtList enchantments = item.getEnchantments(); // Ottieni gli incantamenti
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");

            if ("minecraft:mending".equals(enchantmentId)) { // Controlla l'ID dell'incantamento
                return true;
            }
        }
        return false;
    }
}
