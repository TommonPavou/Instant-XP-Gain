package github.tommonpavou.interfaces;

// Serve per aggiungere attributi agli oggetti (entita' di XP)
public interface EnderDragonExperienceOrb {
    boolean isFromEnderDragon();
    void setFromEnderDragon(boolean value);
}