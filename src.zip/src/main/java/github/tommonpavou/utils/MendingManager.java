package github.tommonpavou.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public class MendingManager {

    private static final Random RANDOM = new Random();

    public static int applyMending(Player player, int experience) {
        List<ItemStack> mendingItems = getMendingItems(player);
        if (mendingItems.isEmpty() || experience <= 0) return experience;

        List<ItemStack> damagedItems = new ArrayList<>();

        // Filtra solo gli item effettivamente danneggiati
        for (ItemStack stack : mendingItems) {
            if (stack.isDamaged()) {
                damagedItems.add(stack);
            }
        }

        // Se non ci sono item danneggiati, ritorna l'XP intera
        if (damagedItems.isEmpty()) return experience;
        int remainingXp = experience;

        // Applica l'XP per riparare gli item danneggiati, partendo da quelli in mano
        while (remainingXp > 0 && !damagedItems.isEmpty()) {

            // Se il giocatore ha un item danneggiato in mano, riparalo per primo
            ItemStack item = damagedItems.get(RANDOM.nextInt(damagedItems.size()));

            // Se l'item è completamente riparato, rimuovilo dalla lista
            int damageBefore = item.getDamageValue();
            if (damageBefore <= 0) {
                damagedItems.remove(item);
                continue;
            }

            // Ripara 2 durability per ogni 1 XP (comportamento vanilla)
            int repairAmount = 2;
            int newDamage = Math.max(0, damageBefore - repairAmount);
            item.setDamageValue(newDamage);
            if (item.getDamageValue() <= 0) {
                damagedItems.remove(item);
            }

            remainingXp--;
        }

        return remainingXp;
    }

        public static List<ItemStack> getMendingItems(Player player) {
        List<ItemStack> mendingItems = new ArrayList<>();

            // Armatura
            ItemStack helmet = player.getItemBySlot(EquipmentSlot.HEAD);
            if (helmet.isDamaged() && isMendingPresent(helmet)) mendingItems.add(helmet);
            ItemStack chestplate = player.getItemBySlot(EquipmentSlot.CHEST);
            if (chestplate.isDamaged() && isMendingPresent(chestplate)) mendingItems.add(chestplate);
            ItemStack leggings = player.getItemBySlot(EquipmentSlot.LEGS);
            if (leggings.isDamaged() && isMendingPresent(leggings)) mendingItems.add(leggings);
            ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);
            if (boots.isDamaged() && isMendingPresent(boots)) mendingItems.add(boots);

            // Mani
            ItemStack mainHand = player.getItemBySlot(EquipmentSlot.MAINHAND);
            if (mainHand.isDamaged() && isMendingPresent(mainHand)) mendingItems.add(mainHand);
            ItemStack offHand = player.getItemBySlot(EquipmentSlot.OFFHAND);
            if (offHand.isDamaged() && isMendingPresent(offHand)) mendingItems.add(offHand);

            return mendingItems;
        }

    public static boolean isMendingPresent(ItemStack item) {
        if (item == null || item.isEmpty()) return false;

        // Ottiene la lista di incantamenti dell'item (se presente) e verifica se contiene la chiave MENDING
        ItemEnchantments enchantments = item.getEnchantments();
        return enchantments.keySet().stream().anyMatch(holder -> holder.is(Enchantments.MENDING));
    }
}