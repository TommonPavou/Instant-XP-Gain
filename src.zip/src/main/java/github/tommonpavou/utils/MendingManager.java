package github.tommonpavou.utils;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.component.type.ItemEnchantmentsComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MendingManager {

    public static int applyMending(PlayerEntity player, int experience) {
        List<ItemStack> mendingItems = getMendingItems(player);
        int remainingXp = experience;

        if (!mendingItems.isEmpty()) {
            for (ItemStack item : mendingItems) {
                if (remainingXp > 0) {
                    int damageBefore = item.getDamage();
                    int maxRepair = damageBefore * 2;
                    int repairAmount = Math.min(remainingXp * 2, maxRepair);

                    if (repairAmount > 0) {
                        item.setDamage(Math.max(damageBefore - (repairAmount / 2), 0));
                        remainingXp -= repairAmount / 2;
                    }
                }
            }
        }
        return remainingXp;
    }

    private static List<ItemStack> getMendingItems(PlayerEntity player) {
        // Controlla l'armatura
        List<ItemStack> mendingItems = new ArrayList<>();
        for (ItemStack item : player.getInventory().armor) {
            if (item.isDamaged() && item.hasEnchantments() && isMendingPresent(item)) {
                mendingItems.add(item);
            }
        }

        // Controlla la mano primaria e secondaria
        for (ItemStack item : new ItemStack[]{player.getMainHandStack(), player.getOffHandStack()}) {
            if (item.isDamaged() && item.hasEnchantments() && isMendingPresent(item)) {
                mendingItems.add(item);
            }
        }
        return mendingItems;
    }

    private static boolean isMendingPresent(ItemStack item) {
        if (item == null || item.isEmpty()) {
            return false;
        }

        ItemEnchantmentsComponent enchantments = item.getEnchantments();
        String enchantmentId = enchantments.toString(); // Trasforma la lista di incantamenti in una stringa

        if (enchantmentId.contains("minecraft:mending")) return true; // Verifica se la lista di incantamenti contiene mending
        else return false;
    }
}