package github.tommonpavou.utils;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;

import java.util.ArrayList;
import java.util.List;

public class MendingManager {

    public static int applyMending(PlayerEntity player, int experience) {
        List<ItemStack> mendingItems = getMendingItems(player);

        int remainingXp = experience;

        // Repair mending items
        if (!mendingItems.isEmpty()) {
            for (ItemStack item : mendingItems) {
                if (remainingXp > 0) {
                    int damageBefore = item.getDamage();
                    int maxRepair = damageBefore * 2;
                    int repairAmount = Math.min(remainingXp * 2, maxRepair);

                    if (repairAmount > 0) {
                        item.setDamage(damageBefore - (repairAmount / 2));
                        remainingXp -= repairAmount / 2;
                    }
                }
            }
        }

        return remainingXp;
    }


    private static List<ItemStack> getMendingItems(PlayerEntity player) {
        List<ItemStack> mendingItems = new ArrayList<>();
        for (ItemStack item : player.getItemsEquipped()) {
            if (item.isDamageable() && isMendingPresent(item)) {
                mendingItems.add(item);
            }
        }
        return mendingItems;
    }


    private static boolean isMendingPresent(ItemStack item) {
        NbtList enchantments = item.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");

            if ("minecraft:mending".equals(enchantmentId)) {
                return true;
            }
        }
        return false;
    }
}
