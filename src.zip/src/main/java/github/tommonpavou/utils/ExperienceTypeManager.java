package github.tommonpavou.utils;

import github.tommonpavou.interfaces.EnderDragonExperienceOrb;
import net.minecraft.entity.ExperienceOrbEntity;

public class ExperienceTypeManager {

    public static boolean isExperienceOrbFromEnderDragon(ExperienceOrbEntity xpOrb) {
        if (xpOrb instanceof EnderDragonExperienceOrb) {
            return ((EnderDragonExperienceOrb) xpOrb).isFromEnderDragon();
        }
        return false;
    }

    public static void setExperienceOrbFromEnderDragon(ExperienceOrbEntity xpOrb, boolean value) {
        if (xpOrb instanceof EnderDragonExperienceOrb) {
            ((EnderDragonExperienceOrb) xpOrb).setFromEnderDragon(value);
        }
    }
}
