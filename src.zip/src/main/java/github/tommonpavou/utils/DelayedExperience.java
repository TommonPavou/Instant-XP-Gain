package github.tommonpavou.utils;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Consegna l'XP delle kill un tick dopo il completamento dell'attacco Vanilla
public final class DelayedExperience {

    private static final List<PendingExperience> PENDING = new ArrayList<>();
    private static boolean registered;

    private DelayedExperience() {
    }

    public static void schedule(Player player, int experience) {
        if (!registered) {
            registered = true;
            ServerTickEvents.END_SERVER_TICK.register(DelayedExperience::onServerTickEnd);
        }

        // Il primo evento è la fine del tick della kill
        // Il secondo evento è quello successivo
        PENDING.add(new PendingExperience(player, experience, 2));
    }

    private static void onServerTickEnd(MinecraftServer server) {
        Iterator<PendingExperience> iterator = PENDING.iterator();

        while (iterator.hasNext()) {
            PendingExperience pending = iterator.next();
            pending.ticksRemaining--;

            if (pending.ticksRemaining > 0) {
                continue;
            }

            iterator.remove();

            if (!pending.player.isAlive() || pending.player.isRemoved()) {
                continue;
            }

            int remainingXp = MendingManager.applyMending(pending.player, pending.experience);
            if (remainingXp > 0) {
                pending.player.giveExperiencePoints(remainingXp);
            }
        }
    }

    private static final class PendingExperience {
        private final Player player;
        private final int experience;
        private int ticksRemaining;

        private PendingExperience(Player player, int experience, int ticksRemaining) {
            this.player = player;
            this.experience = experience;
            this.ticksRemaining = ticksRemaining;
        }
    }
}
