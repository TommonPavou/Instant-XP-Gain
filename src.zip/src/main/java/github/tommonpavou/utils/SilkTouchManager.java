package github.tommonpavou.utils;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public class SilkTouchManager {

    public static boolean isSilkTouchPresent(ItemStack item) {
        if (item == null || item.isEmpty()) return false;

        // Ottiene la lista di incantamenti dell'item (se presente) e verifica se contiene la chiave SILK_TOUCH
        ItemEnchantments enchantments = item.getEnchantments();
        return enchantments.keySet().stream().anyMatch(holder -> holder.is(Enchantments.SILK_TOUCH));
    }
}