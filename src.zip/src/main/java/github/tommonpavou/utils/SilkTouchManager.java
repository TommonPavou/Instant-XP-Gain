package github.tommonpavou.utils;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;

public class SilkTouchManager {

    public static boolean hasSilkTouch(ItemStack tool) {
        if (tool == null || tool.isEmpty()) {
            return false;
        }

        NbtList enchantments = tool.getEnchantments();
        for (int i = 0; i < enchantments.size(); i++) {
            NbtCompound enchantmentData = enchantments.getCompound(i);
            String enchantmentId = enchantmentData.getString("id");
            if ("minecraft:silk_touch".equals(enchantmentId)) return true;
        }

        return false;
    }
}
