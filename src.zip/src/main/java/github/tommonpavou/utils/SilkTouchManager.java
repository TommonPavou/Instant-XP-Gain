package github.tommonpavou.utils;

import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.ItemStack;

public class SilkTouchManager {

    public static boolean hasSilkTouch(ItemStack tool) {

        if (tool == null || tool.isEmpty()) {
            return false;
        }

        ItemEnchantmentsComponent enchantments = tool.getEnchantments();
        String enchantmentId = enchantments.toString(); // Trasforma la lista di incantamenti in una stringa

        if (enchantmentId.contains("minecraft:silk_touch")) return true; // Verifica se la lista di incantamenti contiene silk touch
        else return false;
    }
}